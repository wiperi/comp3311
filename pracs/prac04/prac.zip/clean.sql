--  This script removes the Beer v2 database
--
--  Clean up tables
--  Note: the order of dropping tables is important

drop table Sells;
drop table Likes;
drop table Frequents;
drop table Bars;
drop table Drinkers;
drop table Beers;
drop table Brewers;
