copy Host from '/home/cs3311/web/11s1/prac/03/Host';
copy Session from '/home/cs3311/web/11s1/prac/03/Session';
copy Access from '/home/cs3311/web/11s1/prac/03/Access';
