psql bank -c 'select * from q1 order by suburb;'
