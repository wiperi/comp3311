-- COMP3311 23T1 Final Exam
-- Q1: suburbs with the most customers

-- replace this line with any helper views --

create or replace view q1(suburb,ncust)
as
-- replace this line with your SQL code --
;
