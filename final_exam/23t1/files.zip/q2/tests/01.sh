psql bank -c 'select * from q2 order by name;'
