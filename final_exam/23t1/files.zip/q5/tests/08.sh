python3 ./q5.py 'St Leonards'
