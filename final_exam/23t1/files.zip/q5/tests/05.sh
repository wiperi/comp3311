python3 ./q5.py Willoughby
