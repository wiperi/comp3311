-- COMP3311 23T1 Final Exam
-- Q5: Helper views and functions to support q5

