-- COMP3311 23T1 Final Exam
-- Q3: show branches where
-- *all* customers who hold accounts at that branch
-- live in the suburb where the branch is located

-- replace this line with any helper views --

create or replace view q3(branch)
as
-- replace this line with your SQL code --
;
