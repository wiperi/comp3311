psql bank -c 'select * from q3 order by branch;'
