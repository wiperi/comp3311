-- COMP3311 23T1 Final Exam
-- Q4: Check whether account balance is consistent with transactions

-- replace this line with any helper views or functions --

create or replace function q4(_acctID integer)
	returns text
as $$
-- replace this line with your PLpgSQL code --
$$ language plpgsql;
