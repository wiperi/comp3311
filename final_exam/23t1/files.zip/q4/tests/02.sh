psql bank -c 'select q4(613305);'
