psql bank -c 'select q4(654167);'
