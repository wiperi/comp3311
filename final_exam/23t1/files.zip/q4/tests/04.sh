psql bank -c 'select q4(606100);'
