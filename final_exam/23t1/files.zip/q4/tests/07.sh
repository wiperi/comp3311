psql bank -c 'select q4(652726);'
