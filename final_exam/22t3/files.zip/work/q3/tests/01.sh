psql racing -c "select * from q3('Guineas') order by race;"
