psql racing -c "select * from q3('Classic') order by race;"
