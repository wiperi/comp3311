psql racing -c "select * from q3('Cup') order by race;"
