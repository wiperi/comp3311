psql racing -c "select * from q4('pony') order by horse;"
