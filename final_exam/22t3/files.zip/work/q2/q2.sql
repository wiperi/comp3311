-- COMP3311 22T3 Final Exam Q2
-- List of races with only Mares

-- put helper views (if any) here

-- answer: Q2(name,course,date)

create or replace view Q2(name,course,date)
as
... put sql here ...
;
