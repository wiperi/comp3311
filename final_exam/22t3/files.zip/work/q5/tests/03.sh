python3 ./q5 Flemington 2018-01-01
