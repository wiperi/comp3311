python3 ./q5 Randwick 2019-12-26
