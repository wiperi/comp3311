python3 ./q5 "Moonee Valley" 2019-10-25
