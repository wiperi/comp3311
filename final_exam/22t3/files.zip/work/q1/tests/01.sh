psql racing -c 'select * from q1;'
